package com.example.conectaplus.websocket;

public interface MessageListener {
    void onMessage(String message);
}